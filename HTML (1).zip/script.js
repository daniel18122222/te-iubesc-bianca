document.getElementById("surpriseBtn").addEventListener("click", function() {
    startFireworks();
    typeMessage("Te iubesc din toată inima mea și sunt fericit că ești a mea! ❤️");

    // Pornim muzica
    let audio = document.getElementById("loveSong");
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
    }
});

// Efect scris literă cu literă
function typeMessage(text) {
    let i = 0;
    let messageElement = document.getElementById("typedMessage");
    messageElement.innerHTML = "";

    function typing() {
        if (i < text.length) {
            messageElement.innerHTML += text.charAt(i);
            i++;
            setTimeout(typing, 100);
        }
    }
    typing();
}

// Citate romantice aleatorii
const quotes = [
    "Te iubesc nu doar pentru ceea ce ești, ci și pentru ceea ce sunt eu când sunt cu tine. ❤️",
    "Inima mea bate doar pentru tine! 💖",
    "Dacă dragostea ar fi un ocean, noi am fi infinitul. 🌊",
    "Tu ești visul meu devenit realitate. 💫"
];

document.getElementById("quoteBtn").addEventListener("click", function() {
    let randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    document.getElementById("quoteMessage").innerHTML = randomQuote;
    document.getElementById("quoteMessage").classList.remove("hidden");
});

// Artificii romantice
const canvas = document.getElementById("fireworks");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let fireworks = [];

function startFireworks() {
    setInterval(() => {
        fireworks.push(new Firework());
    }, 300);
}

function Firework() {
    this.x = Math.random() * canvas.width;
    this.y = canvas.height;
    this.color = `hsl(${Math.random() * 360}, 100%, 50%)`;
    this.size = Math.random() * 3 + 2;
    this.speed = Math.random() * 4 + 2;
}

Firework.prototype.update = function() {
    this.y -= this.speed;
    this.size *= 0.98;
};

Firework.prototype.draw = function() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
};

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    fireworks.forEach((firework, index) => {
        firework.update();
        firework.draw();
        if (firework.size < 0.5) {
            fireworks.splice(index, 1);
        }
    });
    requestAnimationFrame(animate);
}

animate();